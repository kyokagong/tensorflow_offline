.. highlight:: cython

.. _interfacing_with_other_code:

***************************
Interfacing with Other Code
***************************

==
C
==

===
C++
===

=======
Fortran
=======

=====
NumPy
=====



